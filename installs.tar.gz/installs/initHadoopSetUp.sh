#!/bin/bash
chmod +x ~/installs/keygen.sh
chmod +x ~/installs/installHadoop.sh
ln -s ~/installs/initHadoopSetUp.sh ~/initHadoopSetUp.sh
ln -s ~/installs/installHadoop.sh ~/installHadoop.sh
~/installs/keygen.sh

