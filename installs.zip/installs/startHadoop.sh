#!/bin/bash
echo "Starting Hadoop"
start-dfs.sh
start-yarn.sh


