#!/bin/bash
echo "Restarting Hadoop"
~/installs/stopHadoop.sh
~/installs/startHadoop.sh


