#!/bin/bash
echo "Stopping Hadoop"
stop-dfs.sh
stop-yarn.sh
